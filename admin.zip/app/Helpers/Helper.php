<?php

namespace App\Helpers;
use App\Test_section_mapping;
use App\Section;
use App\Test;
use App\User_taken_section;

class Helper {

    public static function get_test_sections($id) 
    {
      $sections_name = "";
      if($id)
      {
        $sections_name_array = array();
        $sections = Test_section_mapping::leftjoin("sections", "test_section_mappings.section_id", "=", "sections.id")
          ->select('sections.section')
          ->orderBy("sections.section", "ASC")
          ->where('test_section_mappings.test_id',$id)
          ->get();
        if(count($sections))
        {
          foreach ($sections as $row) 
          {
            array_push($sections_name_array, $row->section);
          }
          if($sections_name_array)
            $sections_name = implode(", ", $sections_name_array);
          //$sections_name = "<ul><li>".implode("</li><li>", $sections_name_array)."</li></ul>";
        }
      }
      return $sections_name;
    }

    public static function get_remaining_time($id, $test_id, $section_id) 
    {
      $sections_name = "";
      if(!empty($id) && !empty($test_id) && !empty($section_id))
      {
        $sections_name_array = array();
        $user_section_time = User_taken_section::select('remaining_time_minutes', 'remaining_time_seconds')          
          ->where('user_id', $id)
          ->where('test_id', $test_id)
          ->where('section_id', $section_id)
          ->whereIn('status', [0,1])
          ->first();

        $section_time = Section::select('duration_in_mins')->where('id', $section_id)->first();
        if($user_section_time)
        {
            $original_time = ($section_time->duration_in_mins*60);
            $user_remaining_time = (($user_section_time->remaining_time_minutes*60) + $user_section_time->remaining_time_seconds);
            $remaining = $original_time - $user_remaining_time;
            if($user_remaining_time<60)
              $remaining_time =1;
            else
            $remaining_time = round(($user_remaining_time/60),0,PHP_ROUND_HALF_UP);
        }
        else
        {
          $remaining_time = $section_time->duration_in_mins;
        }
      }
      return $remaining_time;
    }

    public static function get_status($id, $test_id, $section_id) 
    {
      $status = 0;
      if($id)
      {
        $sections = User_taken_section::select('status')
          ->where('user_id', $id)
          ->where('test_id', $test_id)
          ->where('section_id', $section_id)
          ->first();
        $status = $sections['status'];
      }
      return $status;
    }

  public static function get_test_id($test_name) 
      {
        $test_id = 0;
        if($test_name)
        {
          $test = Test::select('id')
            ->where('test_name', $test_name)
            ->first();
          $test_id = $test['id'];
        }
        return $test_id;
      }
  public static function get_section_id($section_name) 
      {
        $section_id = 0;
        if($section_name)
        {
          $section = Section::select('id')
            ->where('section', $section_name)
            ->first();
          $section_id = $section['id'];
        }
        return $section_id;
      }



  
}
