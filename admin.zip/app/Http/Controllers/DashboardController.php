<?php

namespace App\Http\Controllers;
set_time_limit(0);
use Illuminate\Http\Request;
use Session;
use App\Wpaj_user;
use App\Test;
use App\Section;
use App\User_taken_section;
use App\Section_question;
use App\Answer;
use App\User_test_answer;
use App\Question;
use Redirect;
use View;
use App\Test_section_mapping;
use App\Wpaj_pmpro_memberships_user;
use App\Wpaj_pmpro_membership_level;

class DashboardController extends Controller
{

public function index()
{
if(empty(Session::has('loggedin_user_id')))
{
return redirect()->to('login_user')->send();
}
else
{
$user_id = 0;
$sections = array();
if(Session::has('loggedin_user_id'))
$user_id = Session::get('loggedin_user_id');

$max_id = Wpaj_pmpro_memberships_user::where('user_id', $user_id)->max('id');
if($max_id)
$membership_id = Wpaj_pmpro_memberships_user::select('membership_id')->where('id', $max_id)->first();


if($membership_id)
{
$tests = Test::select('id', 'test_name')->where('membership_level_id', $membership_id->membership_id)->get();

$test_ids = array();
foreach($tests as $rows)
{
array_push($test_ids, $rows->id);
}

if($test_ids)
{
foreach($test_ids as $rowst)
{
	$sections = Test_section_mapping::leftjoin("sections", "test_section_mappings.section_id", "=", "sections.id")
	->select('test_section_mappings.test_id', 'sections.id as id', 'sections.section', 'sections.duration_in_mins')
	->whereIn('test_id', $test_ids)
	->get(); 
}

}
} 
return view('front.dashboard.home', ['user_id'=> $user_id, 'tests'=> $tests, 'sections' =>$sections]); 
} 
}

public function usertest($userid, $testid, $sectionid, $qstid)
{
	if(!empty($userid) && !empty($testid) && !empty($sectionid))
	{
		$user_id = base64_decode($userid);
		$test_id = base64_decode($testid);
		$section_id = base64_decode($sectionid);

		$remaining_time_mins = 0;
		$remaining_time_secs = 0;
		$taken_test_id = 0;
		$check_taken_test = User_taken_section::where('user_id', $user_id)
		->where('test_id', $test_id)
		->where('section_id', $section_id)
		->whereIn('status', [0,1])
		->first();

		$section = Section::find($section_id);
		if(!$check_taken_test)
		{

			$time = new User_taken_section;
			$time->user_id = $user_id;
			$time->test_id = $test_id;
			$time->section_id = $section_id;
			$time->remaining_time_minutes = $section->duration_in_mins;
			$time->remaining_time_seconds = "00";
			$time->status = 0;
			$time->save();

			$sec_qst = Section_question::where('section_id', $section_id)->get();			
			
			$count = 1;
			foreach($sec_qst as $row)
			{
				$check_qst_available = User_test_answer::where('user_id',$user_id)
				->where('section_id', $section_id)
				->where('question_id', $row->question_id)
				->first();
				if(!$check_qst_available)
				{
					$user_ans = new User_test_answer;
					$user_ans->question_count = $count;
					$user_ans->user_id = $user_id;
					$user_ans->section_id = $section_id;
					$user_ans->question_id = $row->question_id;
					$user_ans->come_back_later = 0;
					$user_ans->save();
					$count++;
				}
			}
			$taken_test_id = $time->id;
			$remaining_time_mins = $section->duration_in_mins;
		} 
		else
		{
			$taken_test_id = $check_taken_test->id;
			$remaining_time_mins = $check_taken_test->remaining_time_minutes;
			$remaining_time_secs =$check_taken_test->remaining_time_seconds;

			$check_pause_test = User_taken_section::where('user_id', $user_id)
			->where('test_id', $test_id)
			->where('section_id', $section_id)
			->where('status', 1)
			->first();
			if($check_pause_test)
			{
				$check_pause_test->status = 0;
				$check_pause_test->save();
			}
		} 

		$qst_count = Section_question::where('section_id', $section_id)->count();

		$qst = User_test_answer::leftjoin("questions", "user_test_answers.question_id", "=", "questions.id")
		->select('questions.*', 'user_test_answers.question_id as question_id', 'user_test_answers.user_answer_id')
		->where('user_id', $user_id)
		->where('section_id', $section_id)
		->where('question_count', $qstid)
		->first();

		$all_qst = User_test_answer::where('user_id',$user_id)
		->where('section_id', $section_id)
		->get();

		/*dd($all_qst);die;*/
		$answers = array();
		if($qst)
		{
			$answers = Answer::where('question_id', $qst->question_id)->get();
		}

		$max_id = Wpaj_pmpro_memberships_user::where('user_id', $user_id)->max('id');
		if($max_id)
			$membership_id = Wpaj_pmpro_memberships_user::select('membership_id')->where('id', $max_id)->first();	

		if($membership_id)
			$membership_level = Wpaj_pmpro_membership_level::where("id", $membership_id->membership_id)->first();

		return view('front.dashboard.tests', ['taken_test_id'=> $taken_test_id, 'test_id'=> $test_id, 'section_id'=> $section_id, 'user_id'=> $user_id, 'section' =>$section, 'membership_level' =>$membership_level, 'remaining_time_mins' =>$remaining_time_mins, 'remaining_time_secs' =>$remaining_time_secs, 'qst' =>$qst , 'answers' =>$answers, 'qst_count' =>$qst_count, 'all_qst' =>$all_qst]); 
		}
		else
		{
			return redirect()->back();
		}
	}

public function savetimer(Request $request)
{
	$id = $request->id;
	$time = explode(':', $request->time);
	$update_time = User_taken_section::find($id);
	$update_time->remaining_time_minutes = $time[0];
	$update_time->remaining_time_seconds = $time[1];
	$update_time->save();
	echo 1;
}

public function next_question(Request $request)
{
	$qst = Section_question::select('question_id')
			->where('section_id', $request->section_id)
			->get();

	$qst_array = array();
	$check_qst_array = array();
	$diff_qst_array = array();

	foreach ($qst as $value) 
	{
			array_push($qst_array, $value->question_id);
	}	

	$check_qst = User_test_answer::where("user_id", $request->user_id)->where("section_id", $request->section_id)->get();

	foreach ($check_qst as $val) 
	{
			array_push($check_qst_array, $val->question_id);
	}

	$result=array_diff($qst_array,$check_qst_array);

	foreach ($result as $valr) 
	{
			array_push($diff_qst_array, $valr);
	}

	$qst = Question::select('questions.*', 'questions.id as question_id')
			->whereIn('id', $diff_qst_array)
			->limit(1)
			->get();

	return view('front.dashboard.load_test', ['qst'=> $qst]);
}

public function come_back_later(Request $request)
{
	$user_id = $request->user_id;
	$section_id = $request->section_id;
	$question_id = $request->question_id;
	$count_id = $request->count_id;
	$qst = User_test_answer::where('user_id', $user_id)
	->where('section_id', $section_id)
	->where('question_count', $count_id)
	->where('question_id', $question_id)
	->first();
	$qst->come_back_later = 1;
	$qst->save();
	echo 1;
}
public function set_answer(Request $request)
{
	$user_id = $request->user_id;
	$section_id = $request->section_id;
	$question_id = $request->question_id;
	$answer_id = $request->answer_id;


	$is_correct = 0;
	$ans = Answer::select('id')->where('question_id', $question_id)->where('is_correct', 1)->first();
	if($ans->id == $answer_id)
		$is_correct = 1;

	$qst = User_test_answer::where('user_id', $user_id)
	->where('section_id', $section_id)
	->where('question_id', $question_id)
	->first();

	$qst->user_answer_id = $request->answer_id;
	$qst->is_correct = $is_correct;
	$qst->save();
	echo 1;
}

public function out_of_time($testid, $sectionid)
{
	$test_id = base64_decode($testid);
	$section_id = base64_decode($sectionid);
	$user_id = Session::get('loggedin_user_id');

	$check_taken_test = User_taken_section::where('user_id', $user_id)
	->where('test_id', $test_id)
	->where('section_id', $section_id)
	->where('status', 0)
	->first();

	if($check_taken_test)
	{
		$check_taken_test->remaining_time_minutes = 0;
		$check_taken_test->remaining_time_seconds = 0;
		$check_taken_test->status = 2;
		$check_taken_test->save();
	}
	
	$max_id = Wpaj_pmpro_memberships_user::where('user_id', $user_id)->max('id');
	if($max_id)
		$membership_id = Wpaj_pmpro_memberships_user::select('membership_id')->where('id', $max_id)->first();

	if($membership_id)
			$membership_level = Wpaj_pmpro_membership_level::where("id", $membership_id->membership_id)->first();

	$section = Section::find($section_id);
	return view('front.dashboard.outoftime', ['membership_level'=> $membership_level, 'section'=> $section ]);
}

public function endsection($testid, $sectionid)
{
	$test_id = base64_decode($testid);
	$section_id = base64_decode($sectionid);
	$user_id = Session::get('loggedin_user_id');
	
	$max_id = Wpaj_pmpro_memberships_user::where('user_id', $user_id)->max('id');
	if($max_id)
		$membership_id = Wpaj_pmpro_memberships_user::select('membership_id')->where('id', $max_id)->first();

	if($membership_id)
			$membership_level = Wpaj_pmpro_membership_level::where("id", $membership_id->membership_id)->first();

	$section = Section::find($section_id);
	return view('front.dashboard.end_section', ['membership_level'=> $membership_level, 'section'=> $section ]);
}


public function pauseSection($testid, $sectionid)
{
	$test_id = base64_decode($testid);
	$section_id = base64_decode($sectionid);
	$user_id = Session::get('loggedin_user_id');

	$max_id = Wpaj_pmpro_memberships_user::where('user_id', $user_id)->max('id');
	if($max_id)
		$membership_id = Wpaj_pmpro_memberships_user::select('membership_id')->where('id', $max_id)->first();

	if($membership_id)
			$membership_level = Wpaj_pmpro_membership_level::where("id", $membership_id->membership_id)->first();

	$section = Section::find($section_id);
	return view('front.dashboard.pause_section', ['membership_level'=> $membership_level, 'section'=> $section ]);
}

public function pause($testid, $sectionid)
{
	$test_id = base64_decode($testid);
	$section_id = base64_decode($sectionid);
	$user_id = Session::get('loggedin_user_id');
	
	$check_taken_test = User_taken_section::where('user_id', $user_id)
	->where('test_id', $test_id)
	->where('section_id', $section_id)
	->where('status', 0)
	->first();

	if($check_taken_test)
	{
		$check_taken_test->status = 1;
		$check_taken_test->save();
	}
	return redirect('dashboard');
}

public function end($testid, $sectionid)
{
	$test_id = base64_decode($testid);
	$section_id = base64_decode($sectionid);
	$user_id = Session::get('loggedin_user_id');
	
	$check_taken_test = User_taken_section::where('user_id', $user_id)
	->where('test_id', $test_id)
	->where('section_id', $section_id)
	->where('status', 0)
	->first();

	if($check_taken_test)
	{
		$check_taken_test->status = 2;
		$check_taken_test->save();
	}
	return redirect('dashboard');
}
}
