<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Section_question extends Model
{
    //
}
