<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Test_section_mapping extends Model
{
    //
}
