<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User_taken_section extends Model
{
    //
}
