<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User_test_answer extends Model
{
    //
}
