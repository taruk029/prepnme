<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wpaj_pmpro_membership_level extends Model
{
    //
}
