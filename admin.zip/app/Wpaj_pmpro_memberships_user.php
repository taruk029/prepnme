<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wpaj_pmpro_memberships_user extends Model
{
    //
}
