<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wpaj_user extends Model
{
    //
}
