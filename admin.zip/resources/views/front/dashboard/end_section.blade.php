@extends('front.layout.dashboard_app')
@section('title', 'Dashboard')
@section('content')


    <div class="single-course-content section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-12">
                    <div class="course--content">
                        <div class="header_test">
                            <div class="col-12 col-lg-8" style="float: left;">
                                <p style="margin-top: 10px; line-height: 26px;">SCOOLAR {{ $membership_level->name }}</p>
                                <p class="section_heading">SECTION : {{ $section->section }}</p>
                            </div>
                        
                        </div>

                        <div class="clever-tabs-content">
                            
                            <div class="tab-content" id="myTabContent" >
                                <!-- Tab Text -->
                                <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="tab--1">
                                    <div class="clever-description">
                                        <!-- FAQ -->
                                        <div class="clever-faqs">
                                             <h4>Ready to score this section?</h4>
                                             <p>You won’t be able to come back. Don’t forget to check your work.</p><br>
                                            <center>
                                           <div style="border-top: 1px solid #eeeeee;padding: 20px;">
                                                <a href="{{ url('end/'.Request::segment(2).'/'.Request::segment(3).'/'.Request::segment(4)) }}" class="btn clever-btn" style="width: 300px;background: #e41515;">End & Score</a>

                                                 <a href="{{ $_SERVER['HTTP_REFERER'] }}" class="btn clever-btn" style="width: 300px;">Keep Working</a>
                                           </div>
                                           </center>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Courses Content End ##### -->
@endsection
