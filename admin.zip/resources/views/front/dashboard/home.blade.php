@extends('front.layout.dashboard_app')
@section('title', 'Dashboard')
@section('content')
<style type="text/css">
    svg text {
   font-family: FontAwesome;
}
</style>


    <div class="single-course-content section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-12">
                    <div class="course--content">

                        <div class="clever-tabs-content">
                            
                            <div class="tab-content" id="myTabContent">
                                <!-- Tab Text -->
                                <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="tab--1">
                                    <div class="clever-description">
                                        <!-- FAQ -->
                                        <div class="clever-faqs">
                                            <h4>Your Tests</h4>

                                            <div class="accordions" id="accordion" role="tablist" aria-multiselectable="true">
                                                <?php $sn=1; ?>
                                                @if($tests)
                                                    @foreach($tests as $rows)
                                                <!-- Single Accordian Area -->
                                                <div class="panel single-accordion">
                                                    <h6><a role="button" <?php if($sn!=1) { echo 'class="collapsed"'; } ?>   aria-controls="collapse{{$sn}}" data-toggle="collapse" data-parent="#accordion" href="#collapse{{$sn}}">
                                                        {{ $rows->test_name }}
                                                    <span class="accor-open"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                                    <span class="accor-close"><i class="fa fa-minus" aria-hidden="true"></i></span>
                                                    </a></h6>                                                    
                                                    <div id="collapse{{$sn}}" class="accordion-content collapse <?php if($sn==1) { echo "show"; } ?>">
                                                        <ul class="list-group" style="padding: 4px;">
                                                            @if($sections)
                                                                @foreach($sections as $rowsec)
                                                                    <?php if($rowsec->test_id == $rows->id) 
                                                                    {
                                                                       $status = App\Helpers\Helper::get_status($user_id, $rows->id, $rowsec->id);
                                                                    ?>
                                                                        <li class="list-group-item <?php if($status==2) echo "test_completed"; ?>"  >
                                                                                <div class="row" style="height: 68px;">
                                                                                    <div class="col-md-2">
                                                                                       <svg width="100" height="100">
                                                                                          <circle cx="32" cy="32" r="28" stroke="#eeeeee" stroke-width="4" fill="transparent" />
                                                                                          <?php if($status!=2)
                                                                                          { ?>
                                                                                        <text fill="#000000" font-size="15" x="22" y="38">{{ App\Helpers\Helper::get_remaining_time($user_id, $rows->id, $rowsec->id)?App\Helpers\Helper::get_remaining_time($user_id, $rows->id, $rowsec->id): $rowsec->duration_in_mins }}</text>
                                                                                    <?php } else { ?>
                                                                                        <text fill="#000000" font-size="15" x="22" y="38">&#xf00c;</text>
                                                                                    <?php } ?>
                                                                                        </svg>
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                       <span style="line-height: 3; text-align: left; font-size: 18px;"> {{ $rowsec->section }}</span>
                                                                                    </div>
                                                                                    <div class="col-md-4" style="line-height: 4.2;">
                                                                                        <div class="register-login-area">
                                                                                            <?php 
                                                                                            if($status==1)
                                                                                            { ?>
                                                                                                <a href="{{ url('user_test/'.base64_encode($user_id).'/'.base64_encode($rows->id).'/'.base64_encode($rowsec->id).'/1')}}" class="btn" style="text-transform: capitalize !important;">Continue <i class="fa fa-arrow-right" aria-hidden="true"></i></a>

                                                                                            <?php }
                                                                                            elseif($status!=2)
                                                                                          { ?>
                                                                                            <a href="{{ url('user_test/'.base64_encode($user_id).'/'.base64_encode($rows->id).'/'.base64_encode($rowsec->id).'/1')}}" class="btn" style="text-transform: capitalize !important;">Start <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                                                                                            <?php } else { ?>
                                                                                                <a href="{{ url('analysis/'.base64_encode($user_id).'/'.base64_encode($rows->id).'/'.base64_encode($rowsec->id).'/1')}}" class="btn" style="text-transform: capitalize !important;"> <i class="fa fa-bar-chart" aria-hidden="true"></i>View Result</a>
                                                                                                <?php } ?>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                
                                                                        </li>
                                                                    <?php  } ?>
                                                                @endforeach
                                                            @endif
                                                        </ul>
                                                    </div>
                                                </div>
                                                 <?php $sn++; ?>
                                                    @endforeach
                                                @endif
                                                <!-- Single Accordian Area -->
                                                <!-- <div class="panel single-accordion">
                                                    <h6>
                                                        <a role="button" class="collapsed" aria-expanded="true" aria-controls="collapseTwo" data-parent="#accordion" data-toggle="collapse" href="#collapseTwo">What is the refund policy?
                                                        <span class="accor-open"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                                        <span class="accor-close"><i class="fa fa-minus" aria-hidden="true"></i></span>
                                                        </a>
                                                    </h6>
                                                    <div id="collapseTwo" class="accordion-content collapse">
                                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel lectus eu felis semper finibus ac eget ipsum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vulputate id justo quis facilisis.</p>
                                                    </div>
                                                </div> -->
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-4" style="display: none; background-repeat: repeat-x;
    background-image: -webkit-linear-gradient(135deg, #65a844 0, #fff 150%);
    background-image: -o-linear-gradient(135deg, #65a844 0, #fff 150%);
    background-image: linear-gradient(135deg, #65a844 0, #fff 150%); padding: 20px; height: 400px; border-radius: 5px; border: 1px solid #65a844">
                    <h3 style='text-transform: uppercase;
                        margin: 0 0 5px 0;
                        color: #fff;    font-size: 23px;'>Upgrade your account to get the practice you need!</h3>
                    <ul style="color: #fff;list-style-type: disc !important; padding: 20px; line-height: 25px;">
                        <li><i class="fa fa-angle-right"></i> Full-Length Tests: Online and Printable</li>
                        <li><i class="fa fa-angle-right"></i> Complete Score Report</li>
                        <li><i class="fa fa-angle-right"></i> Over 1200 Practice Exercises</li>
                        <li><i class="fa fa-angle-right"></i> Personalized Prep Plan</li>
                        <li><i class="fa fa-angle-right"></i>  Premium Video Course</li>
                        <li><i class="fa fa-angle-right"></i>  Tutor Consultation</li>
                        <li><i class="fa fa-angle-right"></i>  Official SSAT Practice Tests</li>
                        <li><i class="fa fa-angle-right"></i>  Official SSAT Practice Exercises</li>
                    </ul>
                    <button class="btn btn-success" style="    float: right;">Upgrade</button>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Courses Content End ##### -->
@endsection
