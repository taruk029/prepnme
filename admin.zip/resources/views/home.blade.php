@extends('layouts.app')

@section('content')
     <section id="content">
          <!--start container-->
          <div class="container">
            
            <!--work collections start-->
            <div id="work-collections">
              <div class="row">
                <div class="col s12 m12 l12">
                     <div class="col s12">
                        <div class="card-panel">
                          <blockquote>
                            Welcome to Dashboard (Coming Soon)
                          </blockquote>
                        </div>
                      </div>
                </div>
              </div>
            </div>
            <!--work collections end-->
            
            <!-- //////////////////////////////////////////////////////////////////////////// -->
          </div>
          <!--end container-->
        </section>
@endsection
