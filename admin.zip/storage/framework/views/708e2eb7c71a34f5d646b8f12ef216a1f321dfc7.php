<!-- START FOOTER -->
    <footer class="page-footer gradient-45deg-light-blue-cyan" style="display: none">
        <div class="footer-copyright">
          <div class="container">
            <span>Copyright ©
              <script type="text/javascript">
                document.write(new Date().getFullYear());
              </script> <a class="grey-text text-lighten-2" href="http://themeforest.net/user/pixinvent/portfolio?ref=pixinvent" target="_blank">PIXINVENT</a> All rights reserved.</span>
            <span class="right hide-on-small-only"> Design and Developed by <a class="grey-text text-lighten-2" href="https://pixinvent.com/">PIXINVENT</a></span>
          </div>
        </div>
    </footer>
    <!-- END FOOTER --><?php /**PATH C:\xampp\htdocs\training\admin\resources\views/layouts/footer.blade.php ENDPATH**/ ?>